
<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="important.php">
        <div class="sidebar-brand-icon rotate-n-15">
        </div>
        <div class="sidebar-brand-text mx-3">Admin Panel of G-9 Book Shop</div>
      </a>
      
      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link" href="addproduct.php">
          <span>  |-----Add Book-----|</span></a>
      </li>
      
      <!---next table-->
       <li class="nav-item">
        <a class="nav-link" href="products.php">
          <span> |-------Books-------|</span></a>
      </li>

    </ul>
    <!-- End of Sidebar -->