$(function(){
    $("#xx").show();
    $("#xxx").hide();

   
 $("#th").click(function(){
$("#xx").hide();
$("#xxx").show();
 

        
    });

 $("#sh").click(function(){
 	$("#xxx").hide();
 	$("#xx").show();

 });
 
 $("#sig").click(function(){
   $("#xx").show();
 });
        

});